# INF - 122
Nombre: Tatiana Delgadillo

Materia: INF-122

Color Favorito: #F0F0F0
