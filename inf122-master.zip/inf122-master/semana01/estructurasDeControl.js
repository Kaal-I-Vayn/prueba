var numero = 13;
if (numero % 2 === 0) {
    console.log(numero + ' es par');
} else {
    console.log(numero + ' no es par');
}
if (numero % 5 === 0) {
    console.log(numero + ' es multiplo de 5');
} else {
    console.log(numero + " No es multiplo de 5");
}


for (let i = 0; i <= 5; i++) {
    console.log(i);
}

for (let i = 10; i > 0; i--) {
    console.log(i);
}

let contador = 0;
while (contador < 5) {
    contador++;
    console.log(contador);
}
let contador = 10;
while (contador > 0) {

    console.log(contador);
    contador--;

}
