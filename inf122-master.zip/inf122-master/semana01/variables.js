// Variables globales
var nombre = "Juan";
console.log(nombre);
var apellido = "Sanchez";
console.log(apellido);
var edad = 30;
console.log(edad);
var sueldo = 1.234;
console.log(sueldo);
var casado = true;
console.log(casado);
// Variables de bloque
let presupuesto = 1000;
console.log(presupuesto);
let gastos = 500;
console.log(gastos);
// Constantes
const IVA = 13;
console.log(IVA);
const tipoCambio = 6.98;
console.log(tipoCambio);
var uni = "umsa";
console.log(uni);
let altura = 1.65;
console.log(altura);
const verdad = "arcangel>>>anuel";
console.log(verdad);