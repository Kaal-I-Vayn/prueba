// Aritméticos
let suma = 5 + 5;
console.log(suma);
let resta = 5 - 5;
console.log(resta);
let multiplicacion = 5 * 5;
console.log(multiplicacion);
let division = 5 / 5;
console.log(division);
let modulo = 5 % 5;
console.log(modulo);
// Comparación
let mayorQue = 5 > 5;
console.log(mayorQue);
let mayorIgualQue = 5 >= 5;
let menorQue = 5 < 5;
let menorIgualQue = 5 <= 5;
let igualQue = 5 === 5;
let diferenteQue = 5 != 5;
// Lógicos
let and = true && true;
let or = true || false;
let not = !true;