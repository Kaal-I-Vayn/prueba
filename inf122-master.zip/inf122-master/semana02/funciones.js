function saludar(nombre) {
    return "Hola, " + nombre + "!";
}

const mensaje = saludar("Tatiana");
