import logo from './logo.svg';
import './App.css';
import Evento from './componentes/Evento.js'

function App() {
  return (
    <div className="App">
      <Evento />
    </div>
  );
}

export default App;
